package com.javalec.function;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int fromNum = 1;
		int toNum = 10;
		
		SumEvenOdd sumEvenOdd = new SumEvenOdd(fromNum,toNum);
		int sum = sumEvenOdd.sumCalc();
		
		String result = sumEvenOdd.evenOdd();
		System.out.println(sum + "/"+result);
	}

}

package com.javalec.function;

public class ExamFunction_01 {

	//
	int inputNum = 0;
	//
	public ExamFunction_01() {
		
	}
	public ExamFunction_01(int inputNum) {
		super();
		this.inputNum = inputNum;
	}
	//
	public void gugudan() {
		int result = 0;
		for(int i=1;i<10;i++) {
			result = inputNum * i;
			System.out.println( inputNum+" X "+i+ " = " +result);
		}
		 
	}
	
}

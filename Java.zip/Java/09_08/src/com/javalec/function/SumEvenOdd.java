package com.javalec.function;

public class SumEvenOdd {

	//Field or Property
	private int num1 = 0;
	private int num2 = 0;
	private int sumNum =0;
	
	//
//	public SumEvenOdd(){
//		
//	}
	
	public SumEvenOdd(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}

	
	//Method
	
	
	public int sumCalc() {
		for(int x = num1;x<num2;x++) {
			sumNum+=x;
		}
		return sumNum;
	}
	
	public String evenOdd() {
		String result;
		int j=sumNum%2;
		if(j==0) {
			result = "짝수";
		}else {
			result = "홀수";
		}
		
		return result;
	}
	
	
}

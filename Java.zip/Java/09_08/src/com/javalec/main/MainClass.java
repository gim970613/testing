package com.javalec.main;

import java.util.Scanner;

import com.javalec.function.SumEvenOdd;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =new Scanner(System.in);
		
		int fromNum = 0;//범위 출발 숫자
		int toNum = 0;//끝숫자
		System.out.print("범위의 출발숫자를 입력하세요. :");
		fromNum =scanner.nextInt();
		
		System.out.print("범위의 끝숫자를 입력하세요. :");
		toNum =scanner.nextInt();
		
		SumEvenOdd sumEvenOdd = new SumEvenOdd(fromNum,toNum);// V1.0
		int sum = sumEvenOdd.sumCalc();// V1.0
		String result = sumEvenOdd.evenOdd();// V1.0
		
//		SumEvenOdd sumEvenOdd = new SumEvenOdd();// V1.0
//		int sum = sumEvenOdd.sumCalc();
//		String result = sumEvenOdd.evenOdd();
		
		System.out.println(sum);
		System.out.println(result);

	}

}

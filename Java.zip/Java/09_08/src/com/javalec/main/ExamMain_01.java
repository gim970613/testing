package com.javalec.main;

import java.util.Scanner;

import com.javalec.function.ExamFunction_01;

public class ExamMain_01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int startNum;
		
		System.out.print("구구단을 출력할 숫자를 입력하세요 : ");
		startNum = scanner.nextInt();
		
		ExamFunction_01 examFunction_01 = new ExamFunction_01(startNum);
		examFunction_01.gugudan();
		
		

	}

}

package com.javalec.base;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import com.javalec.function.Gugudan;

public class MainClass {

	public static void main(String[] args) {
		
		
		System.out.print("구구단의 수를 입력 : ");
		Scanner scanner = new Scanner(System.in);
		
		int num = 0;
		String []yaho = new String[10];
		int []muyaho = new int [100];
		
		num = scanner.nextInt();
		
		Gugudan gugudan = new Gugudan(num);
		gugudan.calc();
		
		yaho = gugudan.haha();
		muyaho=gugudan.hehe();
		
//		for(int i =0;i<9;i++) {
//			System.out.println(yaho[i]);
//		}
		System.out.println(Arrays.toString(yaho));
		for(int i =0;i<9;i++) {
			System.out.println(num+"X"+(i+1)+"="+muyaho[i]);
		}
		
		
		
	}

}

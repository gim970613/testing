package com.javalec.function;

public class Gugudan {

	int inputNum = 0;

	public Gugudan(int inputNum) {
		super();
		this.inputNum = inputNum;
	}
	
	public void calc() {
		for(int i=1;i<10;i++) {
			System.out.println(inputNum+"X"+i+"="+(inputNum*i));
		}
	}
	public String []haha(){
		String []out = new String[9];
		for(int i=0;i<9;i++) {
			out[i]= inputNum+"X"+(i+1)+"="+(inputNum*(i+1));
		}
		return out;
	}
	public int []hehe(){
		int []outPut=new int[100];
		for(int i=0;i<9;i++) {
			outPut[i]= inputNum*(i+1);
		}
		return outPut;
	}
	
	
}

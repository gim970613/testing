package Hi;

import java.util.Scanner;



public class Exam01 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int i=0 , j =100 , k,finish=0,end=0,start=0 ;
		int math[]=new int[50];
		int kor[]=new int[50];
		int eng[]=new int[50];
		int user[]=new int[50];
		String Class = "";
		
		
		
////		System.out.println("무슨과목을 확인하시겠습니까?");
////		Class = scanner.nextLine();
////		System.out.println(Class+"를 확인하겠습니다.");
//		
//		
//		System.out.println("성적을 입력하세요 :");
//		i = scanner.nextInt();
		
		
		/*
		if(i>100 || i < 0) {
			System.out.println("성적을 잘못 입력하셨습니다.");
		}else if(i>=90){
			System.out.println("귀하의 학점은 a학점 입니다.");
		
		}else if(i>=80){
			System.out.println("귀하의 학점은 b학점 입니다.");
		
		}else if(i>=70){
			System.out.println("귀하의 학점은 c학점 입니다.");
		
		}else if(i>=60){
			System.out.println("귀하의 학점은 d학점 입니다.");
		}else {
			System.out.println("귀하의 학점은 f학점 입니다.");
		}
		*/

//		if(i>=90)		Class = "A";		
//		else if(i>=80)	Class = "B";		
//		else if(i>=70)	Class = "C";	
//		else if(i>=60)	Class = "D";
//		else 			Class = "F";
//		
//		if(i>100 || i < 0) 	System.out.println("성적을 잘못 입력하셨습니다.");
//		else 				System.out.println("귀하의 학점은 "+Class+"학점 입니다.");
//		
		
//		switch(i/10) {
//		case 10:
//		case 9:
//			Class = "A";
//			break;
//		case 8:
//			Class = "B";
//			break;
//		case 7:
//			Class = "C";
//			break;
//		case 6:
//			Class = "D";
//			break;
//		default:
//			Class = "F";
//			break;
//		}
//		if(i>100 || i < 0) 	System.out.println("성적을 잘못 입력하셨습니다.");
//		else 				System.out.println("귀하의 학점은 "+Class+"학점 입니다.");
//		
		
		
	
		
//		while(true) {
//			System.out.print("시작숫자를 입력하세요 : ");
//			start=scanner.nextInt();
//			System.out.print("끝 숫자를 입력하세요 : ");
//			end=scanner.nextInt();		
//				if(start>end) {
//					System.out.println("잘못입력하셨습니다.");
//					System.out.println("다시 입력해 주세요.");
//				}else {
//					for(i=start;i<=end;i++) {
//						finish=finish+i;
//					}
//					System.out.println(start+"부터"+end+"까지의 합계는 "+finish+"입니다." );
//					break;
//				}
//		}
		
//		------------------------------------------
		
//		System.out.println("구구단으로 사용할 숫자를 입력하세요!");
//		start=scanner.nextInt();
//		for(i=1;i<10;i++) {
//			finish=start*i;
//			System.out.println(start+"X"+i+"="+finish);
//		}
//		
//		for(i=1;i<10;i++) {
//			for(j=1;j<10;j++) {
//				finish = i* j;
//				System.out.print(i+"X"+j+"="+finish+", ");
//			}
//			System.out.println();
//		}
		
		
		
		
	} //main

} //Score

package Hi;

import java.util.Scanner;

public class Exam03 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int number=0,ex=0,total=0;
		int i,j;
		int a;
		
		
		
		
		while(true){
			System.out.println("숫자를 입력해주세요.");
			number=scanner.nextInt();
			System.out.println("범위를 입력해주세요.");
			ex=scanner.nextInt();
			
			if(number>10) {
				System.out.println("10보다 작은수를 입력해주세요.");
			}else {
				for(i=1;i<10;i++) {
					for(j=0;j<ex;j++) {
						a= number + j;
						total = (a) * i;
						System.out.printf(a+"X"+i+"="+String.format
								("%3d",total)+"\t");
					}
				System.out.println();
				}break;
			}
		}
	}

}

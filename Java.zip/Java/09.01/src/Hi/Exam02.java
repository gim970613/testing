package Hi;

import java.util.Scanner;

public class Exam02 {

	public static void main(String[] args) {
		
		int number=0,finish=0,ex=0,asd=1;
		int a=0,b=0,c=0,d=0;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("숫자를 입력해주세요.");
		number=scanner.nextInt();

		
//		for(int i=1;i<10;i++) {
//			finish = number * i ;
//			System.out.print(number+"X"+i+"="+finish);
//			finish = (number+1) * i ;
//			System.out.print("\t"+(number+1)+"X"+i+"="+finish);
//			finish = (number+2) * i ;
//			System.out.print("\t"+(number+2)+"X"+i+"="+finish);
//			finish = (number+3) * i ;
//			System.out.println("\t"+(number+3)+"X"+i+"="+finish);
//		}
		
//		for(int i=1;i<10;i++) {
//			a = number * i ;
//			b = (number+1) * i ;
//			c = (number+2) * i ;
//			d = (number+3) * i ;
//			System.out.print(number+"X"+i+"="+a+"\t");
//			System.out.print((number+1)+"X"+i+"="+b+"\t");
//			System.out.print((number+2)+"X"+i+"="+c+"\t");
//			System.out.println(+(number+3)+"X"+i+"="+d+"\t");
//		}
		for(int i=1;i<10;i++) {
			a = number * i ;
			b = (number+1) * i ;
			c = (number+2) * i ;
			d = (number+3) * i ;
			System.out.println(	a+"X"+i+"="+a+"\t"+
								b+"X"+i+"="+b+"\t"+
								c+"X"+i+"="+c+"\t"+
								d+"X"+i+"="+d+"\t");

		}
		
		
		
		
		
		
		}

}

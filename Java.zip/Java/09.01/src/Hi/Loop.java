package Hi;

public class Loop {

	public static void main(String[] args) {
		int a[]= new int[50];
		int i,j,k=0,jjacksu=0,holsu=0;
//		System.out.println(1);
//		System.out.println(2);
//		System.out.println(3);
//		System.out.println(4);
//		System.out.println(5);
//		System.out.println(6);
//		System.out.println(7);
//		System.out.println(8);
//		System.out.println(9);
//		System.out.println(10);
		
//		for(i = 1;i <= 10;i++) System.out.print(i+", ");
		
//		-------------------------------
		
//		for(i = 1;i <= 1000;i++) {
//			if(i == 5) {
//				System.out.println("OK");
//				break;
//			}
//			System.out.println(i);
//		}
		
		
		//1부터 10까지의 합계 구하기	
//		for(i=1;i<=10;i++) {
//			j = j + i;
//			
//		}
//		System.out.println(j);
		
		//1부터 10까지의 수중 짝수의 합과 홀수 합을 구하기
//		for(i=1;i<=10;i++) {
//			if(i%2==0) 	jjacksu=jjacksu+i;
//			else 		holsu=holsu+i;
//		}
//		System.out.println("짝수의 합은 "+jjacksu);
//		System.out.println("홀수의 합은 "+holsu);
		
//		for(i=1;i<=10;i++) {
//			switch(i%2) {
//			case 0:{
//				jjacksu=jjacksu+i;
//				break;
//			}
//			default:{
//				holsu=holsu+i;
//				break;
//			}
//			}
//		}
//		System.out.println("짝수의 합은 "+jjacksu);
//		System.out.println("홀수의 합은 "+holsu);
		
		for(i=1;i<=10;i+=2) {
			holsu=holsu+i;
		}
		for(i=0;i<=10;i+=2) {
			k=k+i;
		}
		System.out.println("짝수의 합은 "+jjacksu);
		System.out.println("홀수의 합은 "+holsu);
		System.out.println(k);
		
		
		
	}

}

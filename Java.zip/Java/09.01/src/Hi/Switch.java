package Hi;

import java.util.Scanner;



public class Switch {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int inputNumber = 0;//사용자 입
		String resuit ="";// 처리결과 저장소
		
		System.out.println("숫자를 입력하세요.");
		inputNumber=scanner.nextInt();
		
//		if(inputNumber % 2 ==0) {
//			resuit = "짝수";
//		}else {
//			resuit = "홀수";
//		}
		
		switch(inputNumber %2) {
			case 0:
				resuit = "짝수";
				break;
			case 1:
				resuit = "홀수";
				break;
			default:
				break;
		}
		
		System.out.println("입력하신 숫자 "+inputNumber+"는 "+ resuit+" 입니다.");
		
		
		
	}//main

}
